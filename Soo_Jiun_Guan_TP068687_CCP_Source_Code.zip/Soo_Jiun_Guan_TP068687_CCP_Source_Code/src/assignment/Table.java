package assignment;

public class Table {
    enum State { DEFAULT, PRIVATE, SHARED }
    private State state = State.DEFAULT;
    private int occupiedSeats = 0; // Track the number of occupied seats at the table
    private final int tableNumber; // Add table number field

    // Constructor to initialize table number
    public Table(int tableNumber) {
        this.tableNumber = tableNumber;
    }

    public synchronized boolean sitAtTable(boolean prefersPrivate) {
        if (prefersPrivate) {
            if (state == State.DEFAULT && occupiedSeats == 0) {
                state = State.PRIVATE;
                occupiedSeats++;
                return true;
            }
        } else {
            if ((state == State.DEFAULT || state == State.SHARED) && occupiedSeats < 2) {
                state = State.SHARED;
                occupiedSeats++;
                return true;
            }
        }
        return false; // No suitable seating condition met
    }

    public synchronized void leaveTable() {
        occupiedSeats--;
        if (occupiedSeats == 0) {
            state = State.DEFAULT; // Reset table state to default when the last customer leaves
        }
    }

    public synchronized State getState() {
        return state;
    }
    
    // Getter for table number
    public int getTableNumber() {
        return this.tableNumber;
    }
    
    public synchronized int getOccupiedSeats() {
        return this.occupiedSeats;
    }
}
