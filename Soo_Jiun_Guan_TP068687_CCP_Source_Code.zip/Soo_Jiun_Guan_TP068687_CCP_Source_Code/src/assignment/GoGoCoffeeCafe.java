//SOO JIUN GUAN TP068687
//Concurrent Programming Assignment

package assignment;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ConcurrentLinkedQueue;

//Print statement color 
// "\u001B[36m" cyan - seat replacement
// "\u001B[35m" purple - barista become sleeping
// "\u001B[34m" blue - customer found seat successfully
// "\u001B[33m" yellow - machine availability status
// "\u001B[32m green - customer leaves midway
// "\u001B[31m" red - customer leaves after drinking

public class GoGoCoffeeCafe {
    private static final int MAX_CUSTOMERS = 20;
    private static final int MAX_BARISTAS = 3;
    private static final int MAX_WAITING_CUSTOMERS = 5; // Maximum number of customers waiting before new customers leave
    private static final int MAX_WAITING_TIME = 5000; // Maximum waiting time (0.5 minute)
    private static final int LEAVE_PROBABILITY = 30;
    private static final AtomicInteger totalCappuccino = new AtomicInteger(0);
    private static final AtomicInteger totalEspresso = new AtomicInteger(0);
    private static final AtomicInteger totalJuice = new AtomicInteger(0);
    private static final AtomicInteger totalSales = new AtomicInteger(0);
    private static final AtomicInteger activeCustomers = new AtomicInteger(0);
    private static final AtomicInteger lostCustomers = new AtomicInteger(0);
    private static final AtomicInteger waitingOrderCustomer = new AtomicInteger(0);
    private static final AtomicInteger availableBaristas = new AtomicInteger(MAX_BARISTAS); 
    private static final Semaphore espressoMachine = new Semaphore(1);
    private static final Semaphore milkFrothingMachine = new Semaphore(1);
    private static final Semaphore juiceTap = new Semaphore(1);
    private static final Object orderLock = new Object();
    private static final ConcurrentLinkedQueue<Order> orderQueue = new ConcurrentLinkedQueue<>();
    private static final ConcurrentLinkedQueue<Customer> customerQueue = new ConcurrentLinkedQueue<>();
    private static volatile boolean cafeOpen = true;
   
    public static void main(String[] args) throws InterruptedException {
        // Start barista threads
    	Thread[] baristaThreads = new Thread[MAX_BARISTAS];
    	for (int i = 0; i < MAX_BARISTAS; i++) {
    	    baristaThreads[i] = new Thread(new Barista(), "Barista-" + (i + 1));
    	    baristaThreads[i].start();
    	}
    	
    	Thread[] customerThreads = new Thread[MAX_CUSTOMERS];
    	for (int i = 0; i < MAX_CUSTOMERS; i++) {
    		Thread.sleep(new Random().nextInt(3) * 1000);
    	    customerThreads[i] = new Thread(new Customer(), "Customer-" + (i + 1));
    	    customerThreads[i].start();
    	}
 
    	for (Thread customerThread : customerThreads) {
    	    customerThread.join(); // Wait for all customer threads to finish
    	}
    	        
        cafeOpen = false; // Set cafeOpen to false here if not already set
        synchronized (orderLock) {
            orderLock.notifyAll(); // Final notifyAll to ensure no baristas are indefinitely waiting
        }

        for (Thread baristaThread : baristaThreads) {
            baristaThread.join();         // Wait for all barista threads to finish
        }

        // Now print the closing summary
        System.out.println("Cafe is closing. Total sales: RM" + totalSales);
        System.out.println("Total Cappuccino （RM 9/per） sold: " + totalCappuccino);
        System.out.println("Total Espresso （RM 6/per） sold: " + totalEspresso);
        System.out.println("Total Juice （RM 7/per） sold: " + totalJuice); 
        System.out.println("Number of customers that have been lost: " + lostCustomers); 
    }

    static class Barista implements Runnable {
        @Override
        public void run() {
            boolean wasWaiting = false;
            while (cafeOpen || !orderQueue.isEmpty() || activeCustomers.get() > 0) {
                Order order = null;
                synchronized (orderLock) {
                    while (orderQueue.isEmpty() && cafeOpen) {
                        try {
                            if (!wasWaiting) {
                                System.out.println("\u001B[35m" + "\t" + CafeTime.getRandomActionTime() + " - " 
                            +  Thread.currentThread().getName() 
                            + " become sleeping state and is waiting for orders."  + "\u001B[0m");
                                wasWaiting = true;
                            }
                            orderLock.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    order = orderQueue.poll();
                    wasWaiting = false;
                }
                if (order != null) {
                    availableBaristas.decrementAndGet(); // Decrement available baristas as this one is now busy
                    prepareOrder(order);
                    availableBaristas.incrementAndGet(); // Increment available baristas as this one is now free
                } else if (!cafeOpen) {
                    System.out.println(CafeTime.getRandomActionTime() + " - " 
                + Thread.currentThread().getName() + " is closing down.");
                    break;
                }
            }
        }

        private void prepareOrder(Order order) {
        	System.out.println(CafeTime.getRandomActionTime() + " - " + Thread.currentThread().getName() 
            		+ " is responsible for the order of " + order.customerName);
        	System.out.println(CafeTime.getRandomActionTime() + " - " + Thread.currentThread().getName()
        			+ " start preparation of " + order.orderType + " for " + order.customerName);
            try {
                switch (order.orderType) {
                    case "Cappuccino":
                        makeCappuccino(order.customerName);
                        break;
                    case "Espresso":
                        makeEspresso(order.customerName);
                        break;
                    case "Juice":
                        makeJuice(order.customerName); 
                        break;
                }
                System.out.println(CafeTime.getRandomActionTime() 
                		+ " - " + order.orderType + " for " + order.customerName + " is ready.");
                order.orderReady(); // Mark the order as ready and notify the customer
            } catch (InterruptedException e) {
            	e.printStackTrace();
            }
        }

        private void makeCappuccino(String customerName) throws InterruptedException {
            acquireMachine(espressoMachine, "Espresso Machine");
            Thread.sleep(1000);
            releaseMachine(espressoMachine, "Espresso Machine");
            acquireMachine(milkFrothingMachine, "Milk Frothing Machine");
            Thread.sleep(500);
            releaseMachine(milkFrothingMachine, "Milk Frothing Machine");
            totalCappuccino.incrementAndGet();
            totalSales.addAndGet(9);
        }

        private void makeEspresso(String customerName) throws InterruptedException {
            acquireMachine(espressoMachine, "Espresso Machine");
            Thread.sleep(1000);
            releaseMachine(espressoMachine, "Espresso Machine");
            totalEspresso.incrementAndGet();
            totalSales.addAndGet(6);
        }

        private void makeJuice(String customerName) throws InterruptedException {
            acquireMachine(juiceTap, "Juice Tap");
            Thread.sleep(1500);
            releaseMachine(juiceTap, "Juice Tap");
            totalJuice.incrementAndGet();
            totalSales.addAndGet(7);
        }

        private void acquireMachine(Semaphore machine, String machineName) throws InterruptedException {
        	synchronized (orderLock) {
	            int available = machine.availablePermits(); // Check available permits before acquiring
	            String availabilityStatus = available > 0 ? "available" : "in use";
	            System.out.println(CafeTime.getRandomActionTime() + " - " + Thread.currentThread().getName() 
	                    + " is trying to use the " + machineName + ". Status: " + "\u001B[33m" 
	            		+ availabilityStatus  + "\u001B[0m" + ".");
        	}
            machine.acquire();
            System.out.println(CafeTime.getRandomActionTime() + " - " + Thread.currentThread().getName() 
            		+ " is using the " + machineName + ".");
        }

        private void releaseMachine(Semaphore machine, String machineName) {
            machine.release();
            System.out.println(CafeTime.getRandomActionTime() + " - " + Thread.currentThread().getName() 
            		+ " has finished using the " + machineName + ".");
        }
  
    }
    
    static class Customer implements Runnable {
        private String orderType;
        private boolean prefersPrivate = (new Random().nextBoolean());;
        private long startTime = System.currentTimeMillis();
        private Table chosenTable = null;
        private boolean inLine = false;
        private boolean switchSeat = false;
        private static Table[] tables = new Table[5];
        static {
            for (int i = 0; i < tables.length; i++) {
                tables[i] = new Table(i + 1); // Initialize each table with a unique number
            }
        }
        
        private boolean checkBaristaAvailable() {
            synchronized (orderLock) {
                if (availableBaristas.get() == 0) {
                	if(shouldLeave()) {
                		waitingOrderCustomer.decrementAndGet(); 
                		lostCustomers.incrementAndGet();
                		leaveCafe();
	                    System.out.println("\u001B[32m" + "\t\t" + CafeTime.getRandomActionTime() + " - " 
	                + Thread.currentThread().getName() 
	                + " noticed that all three baristas were busy and he/she didn't want to wait then leaves." + "\u001B[0m");
	                    return false;
                	}
                	else {
                		System.out.println("\t" + CafeTime.getRandomActionTime() + " - " 
            	                + Thread.currentThread().getName() 
            	                + " noticed that all three baristas were busy but he/she is still willing to wait.");
                		return true;
                	}
                }
                return true;
            }
        }
        
        @Override
        public void run() {
            System.out.println("\t" + CafeTime.getRandomActionTime() + " - " 
            + Thread.currentThread().getName() + " arrives and prefers a " 
            + (prefersPrivate ? "private" : "shared") + " table.");
            if (!tryEnterCafe()) return; // Check if cafe is too full and increment active customer count
            if(!checkBaristaAvailable()) return;
            try {
                Table chosenTable = findTableWithinTimeout();               
                // Simulate customer behavior after finding a table
                if (chosenTable != null) { // Add this check to ensure chosenTable is not null
                    // Simulate customer behavior after finding a table
                    simulateCustomerActivity(chosenTable);
                }
            } finally {
                leaveCafe(); // Ensure active customer count is decremented when leaving
            }
        }

        private boolean tryEnterCafe() {
            synchronized (orderLock) {
                if (waitingOrderCustomer.get() >= MAX_WAITING_CUSTOMERS) {
                	lostCustomers.incrementAndGet();
                    System.out.println("\u001B[32m" + "\t\t" + CafeTime.getRandomActionTime() + " - " 
                + Thread.currentThread().getName() + " finds the cafe too full and leaves immediately." + "\u001B[0m");
                    return false;
                }
                waitingOrderCustomer.incrementAndGet(); 
                activeCustomers.incrementAndGet();
                return true;
            }
        }
        
        private String getOrderType() {
            int orderChoice = (new Random().nextInt(10));
            if (orderChoice < 7) {
                return "Cappuccino";
            } else if (orderChoice < 9) {
                return "Espresso";
            } else {
                return "Juice";
            }
        }

        private void leaveCafe() {
            activeCustomers.decrementAndGet();
        }

        private Table findTableWithinTimeout() {
        	customerQueue.add(this); // Add this customer to the queue
            while ((System.currentTimeMillis() - startTime) < MAX_WAITING_TIME && chosenTable == null) {
                synchronized (tables) {
                    for (Table table : tables) {
                        if (table.sitAtTable(prefersPrivate)) {
                            chosenTable = table;
                            customerQueue.poll(); // Remove this customer from the queue
                            announceTableFound(chosenTable);
                            return chosenTable;
                        }
                    }
                }
                if (!inLine) { // Show once time only
                    System.out.println("\t" + CafeTime.getRandomActionTime() + " - " 
                + Thread.currentThread().getName() + " is standing in line, waiting for a table.");
                    inLine = true;
                }
                if((System.currentTimeMillis() - startTime) < MAX_WAITING_TIME/2 
                		&& chosenTable == null && switchSeat == false)
                {
                	prefersPrivate = false;
                	switchSeat = true;
                	System.out.println("\u001B[36m" + "\t\t" + CafeTime.getRandomActionTime() + " - " 
                	+ "Out of desperation, " + Thread.currentThread().getName() 
                	+ " is willing to switch to a shared table after a period." + "\u001B[0m");
                }
            }
            // Check if the customer wants to leave due to tiredness
            lostCustomers.incrementAndGet();
            System.out.println("\u001B[32m" + "\t\t" + CafeTime.getRandomActionTime() + " - " 
        + Thread.currentThread().getName() + " gets tired of waiting and leaves the cafe." + "\u001B[0m");
            leaveCafe();
            customerQueue.remove(this); // Ensure the customer is removed from the queue if they leave
            return null; // Return null if no table is found within the timeout
        }
        
        private boolean shouldLeave() {
            return new Random().nextInt(100) < LEAVE_PROBABILITY;
        }

        private void announceTableFound(Table table) {
        	System.out.println("\u001B[34m" + "\t\t" + CafeTime.getRandomActionTime() + "  - " 
        + Thread.currentThread().getName() + " found a " + (prefersPrivate ? "private" : "shared") 
        + " table at table number " + table.getTableNumber() + (prefersPrivate ? "" :" with (" 
        + table.getOccupiedSeats()+ "/2) occupied seat(s).") + "\u001B[0m");
        }

        private void simulateCustomerActivity(Table chosenTable) {
            try {
                System.out.println("\t" + CafeTime.getRandomActionTime() + " - " 
                + Thread.currentThread().getName() + " is deciding on his/her order.");

                // Place the order
                orderType = getOrderType();
                Order order = new Order(Thread.currentThread().getName(), orderType);
                System.out.println("\t" + CafeTime.getRandomActionTime() + " - " 
                + Thread.currentThread().getName() + " ordered " + orderType + " and paid for it online.");
                placeOrder(order);
                
             // Wait for the order to be prepared and then enjoy the order
                order.waitForOrder();
                waitingOrderCustomer.decrementAndGet(); 
                System.out.println("\t" + CafeTime.getRandomActionTime() + " - " 
                + Thread.currentThread().getName() + " has received his/her " + orderType 
                + " and is now enjoying it.");
                Thread.sleep(((new Random().nextInt(4) + 4) * 1000)); // Simulate time spent enjoying the drink

                // Leaving the table after finishing
                System.out.println("\u001B[31m" + "\t\t" + CafeTime.getRandomActionTime() 
                + " - " + Thread.currentThread().getName() + " has finished their " + orderType 
                + " and is leaving the table " + chosenTable.getTableNumber() + "." + "\u001B[0m");

            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                chosenTable.leaveTable(); // Ensure the table is marked as available when the customer leaves
            }
        }

        private void placeOrder(Order order) {
            synchronized (orderLock) {
            	orderQueue.add(order);
                orderLock.notifyAll(); // Notify baristas that a new order has been placed
            }
        }

    }

}

        
  