package assignment;

public class Order {
    String customerName;
    String orderType; 
    private boolean isOrderReady = false;

    public Order(String customerName, String orderType) {
        this.customerName = customerName;
        this.orderType = orderType;
    }

    public synchronized void orderReady() {
        isOrderReady = true;
        notify(); // Notify the waiting customer thread that the order is ready
    }

    public synchronized void waitForOrder() throws InterruptedException {
        while (!isOrderReady) {
            wait(); // Wait until the order is ready
        }
    }
}
