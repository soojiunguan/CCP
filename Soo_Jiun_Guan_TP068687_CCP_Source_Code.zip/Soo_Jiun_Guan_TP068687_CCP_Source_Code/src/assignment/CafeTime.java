package assignment;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class CafeTime {
    private static final int OPEN_HOUR = 10; // Cafe opens at 
    private static AtomicInteger currentTime = new AtomicInteger(OPEN_HOUR * 60); // Store time in minutes

    // Method to get a random time for an action and update the current time without checking for a closing time
    public static synchronized String getRandomActionTime() {
        // Now adds up to 1 minute randomly for each action to slow down the time progression
        int currentTimeInMinutes = currentTime.getAndAdd(new Random().nextInt(2)+ 1); // Adjusted to add 0 or 1 minute randomly
        int hours = currentTimeInMinutes / 60;
        int minutes = currentTimeInMinutes % 60;
        // Formatting to ensure it shows proper time format even beyond 24 hours
        hours = hours % 24; // This will roll the hour back to 0 after midnight (24 hours)
        return String.format("%02d:%02d", hours, minutes);
    }
}
